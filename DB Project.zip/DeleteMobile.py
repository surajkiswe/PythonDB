#!C:\Users\suraj\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("content-type:text/html")
print()

print("<body style='background-color: #242F36;'>")
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

try:
    reqobj=cgi.FieldStorage()
    pid=reqobj.getvalue("pid")
            
    con=pymysql.connect(host='bhmacmsjsimpkiljjnab-mysql.services.clever-cloud.com',user='ufydbghpaebd6v1n',password='0IjlotKAgSVDmNJ5QxRT',database='bhmacmsjsimpkiljjnab')
    curs=con.cursor()
    curs.execute("select * from MOBILES where prodid='%s'"%pid)
    data=curs.fetchall()
    if data:
        curs.execute("delete from MOBILES where prodid='%s'"%pid)
        con.commit()
        print("<br>")
        print("<h2 class='display-7' style='color: green; font-family: Cambria, Cochin, Georgia, Times, serif;' >Mobile Deleted Succesfully... </h2>")
        print("<hr style='color: aqua;'>")
        print("<a href='ShowMobiles.py'>Show Mobiles</a>")
        print("<br>")
        print("<a href='MobileWorld.html'>Home</a>")
    else:
        print("<h2 class='display-7' style='color: red;' >Mobile does not exist!</h2><hr style='color: aqua;' >")
        print("<a href='DeleteMobile.html'>Back</a>")
        print("<br>")
        con.close()
        print("<a href='MobileWorld.html'>Home</a>")

except Exception as e:
    print("error",e)
    print("<h2 class='display-7' style='color: red;' >Mobile does not exist</h2><hr>")
    print("<a href='UpdatePrice.html'>Back</a>")
    con.close()
    print("<a href='MobileWorld.html'>Home</a>")
print("</div>")
print("</body>")
con.close()
