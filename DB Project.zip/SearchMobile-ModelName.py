#!C:\Users\suraj\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("content-type:text/html")
print()
print("<body style='background-color: #242F36;'>")
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

try:
    reqobj=cgi.FieldStorage()
    mnm=reqobj.getvalue("mnm")

    con=pymysql.connect(host='bhmacmsjsimpkiljjnab-mysql.services.clever-cloud.com',user='ufydbghpaebd6v1n',password='0IjlotKAgSVDmNJ5QxRT',database='bhmacmsjsimpkiljjnab')
    curs=con.cursor()
    curs.execute("select * from MOBILES where modelname='%s'"%mnm)
    data=curs.fetchall()
    if data:
        print("<br>")
        print("<table class='table table-bordered-color:azure'>")
        print("<tr style='background-color:azure'>")
        print("<th style='color:red;'>Product Id")
        print("<th style='color:red;'>Model Name")
        print("<th style='color:red;'>Company")
        print("<th style='color:red;'>Cellular Technology")
        print("<th style='color:red;'>Ram")
        print("<th style='color:red;'>Rom")
        print("<th style='color:red;'>Color")
        print("<th style='color:red;'>Screen")
        print("<th style='color:red;'>Battery")
        print("<th style='color:red;'>Processor")
        print("<th style='color:red;'>Price")
        print("<th style='color:red;'>Ratings")
        print("</tr>")

        for rec in data:
            print("<tr>")
            print("<td style='color:green;'>",rec[0])
            print("<td style='color:green;'>",rec[1])
            print("<td style='color:green;'>",rec[2])
            print("<td style='color:green;'>",rec[3])
            print("<td style='color:green;'>",rec[4])
            print("<td style='color:green;'>",rec[5])
            print("<td style='color:green;'>",rec[6])
            print("<td style='color:green;'>",rec[7])
            print("<td style='color:green;'>",rec[8])
            print("<td style='color:green;'>",rec[9])
            print("<td style='color:green;'>",rec[10])
            print("<td style='color:green;'>",rec[11])
            print("</tr>")
    
    else:
        print("<h2 class='display-7' style='color: red;' >Mobile not found</h2><hr>")
        print("<a href='SearchMobile.html'>Back</a>")
    
    print("</table>")
    print("<a href='MobileWorld.html'>Home</a>")
    print("</div>")
    print("</body>")
    con.close()

except Exception as e:
    print("error",e)